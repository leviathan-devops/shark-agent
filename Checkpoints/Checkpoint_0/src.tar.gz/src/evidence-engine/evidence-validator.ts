import { validateEvidence, validateEvidenceBatch, type ValidationResult, type EvidenceFile } from './evidence-validator-core.js';
export { validateEvidence, validateEvidenceBatch };
export type { ValidationResult, EvidenceFile };

export class EvidenceValidator {
  private basePath: string;
  constructor(basePath: string) { this.basePath = basePath; }
  validate(evidence: EvidenceFile): ValidationResult { return validateEvidence(evidence); }
  validateBatch(files: EvidenceFile[]): ValidationResult { return validateEvidenceBatch(files); }
}
