import * as ts from 'typescript';
export interface DeadExport { file: string; exportName: string; line: number; }
export function findDeadExports(program: ts.Program, checker: ts.TypeChecker): DeadExport[] {
  const dead: DeadExport[] = [];
  for (const sourceFile of program.getSourceFiles()) {
    if (sourceFile.isDeclarationFile || sourceFile.fileName.includes('node_modules')) continue;
    ts.forEachChild(sourceFile, function visit(node: ts.Node) {
      if (ts.isExportAssignment(node)) {
        const symbol = checker.getSymbolAtLocation(node.expression);
        if (symbol) {
          const refs = checker.findReferences(symbol, sourceFile.fileName);
          if (refs.length === 0) {
            const pos = sourceFile.getLineAndCharacterOfPosition(node.getStart());
            dead.push({ file: sourceFile.fileName, exportName: 'default', line: pos.line + 1 });
          }
        }
      }
      ts.forEachChild(node, visit);
    });
  }
  return dead;
}
