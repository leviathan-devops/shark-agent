import { SemanticFirewall } from '../../semantic-firewall/semantic-firewall.js';
import { ExecutionContext } from '../../semantic-firewall/execution-context.js';
import { isSharkAgent } from '../../shared/agent-identity.js';
import { StructuredBlockError } from '../../shark/enforcement-brain/enforcement-brain.js';
import type { RuleConfig, AnalysisPhase } from '../../semantic-firewall/types.js';

const WRITE_TIME_RULES: RuleConfig[] = [
  { name: 'no-empty-catch', severity: 'HIGH', enabled: true, orders: 2 },
  { name: 'no-unsafe-cast', severity: 'HIGH', enabled: true, orders: 3 },
  { name: 'no-floating-promises', severity: 'MEDIUM', enabled: true, orders: 4 },
  { name: 'evidence-bearing-results', severity: 'HIGH', enabled: true, orders: 2 },
  { name: 'no-hardcoded-paths', severity: 'MEDIUM', enabled: true, orders: 2 },
  { name: 'cleanup-paired-intervals', severity: 'HIGH', enabled: true, orders: 2 },
  { name: 'handle-zero-length', severity: 'LOW', enabled: true, orders: 2 },
];

export function createWriteTimeGate(firewall: SemanticFirewall, context: ExecutionContext) {
  return async (input: any, output: any) => {
    const toolName = input?.tool || '';
    if (!['write', 'edit', 'bash'].includes(toolName)) return;
    const agent = input?.agent || '';
    if (agent && !isSharkAgent(agent)) return;
    const args = (input as any)?.args || (output as any)?.args || {};
    if (context.shouldAllowEngineeringOperation(toolName, args)) return;
    const result = firewall.analyze('write-time' as AnalysisPhase, WRITE_TIME_RULES);
    if (!result.passed) {
      const critical = result.diagnostics.filter(d => d.severity === 'CRITICAL' || d.severity === 'HIGH');
      if (critical.length > 0) {
        const first = critical[0];
        throw new StructuredBlockError({ level: 'BLOCK', lobe: 'semantic-firewall', findingId: 'SF-' + first.rule.toUpperCase(), message: '[' + first.severity + '] ' + first.message, correction: first.message });
      }
    }
    if (toolName === 'edit' || toolName === 'write') {
      const filePath = typeof args.filePath === 'string' ? args.filePath : '';
      if (filePath) context.recordEdit(toolName, filePath);
    }
  };
}
